package com.bootcamp.bankwithdrawal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankwithdrawalApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.bootcamp.bankwithdrawal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankwithdrawalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankwithdrawalApplication.class, args);
	}

}
